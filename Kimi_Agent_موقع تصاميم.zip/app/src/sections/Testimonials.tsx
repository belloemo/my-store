import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: 'UI/UX Designer',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    content: 'The UI kits from DesignCraft are absolutely incredible. They have saved me countless hours on client projects. The quality is unmatched!',
    rating: 5,
  },
  {
    id: 2,
    name: 'Michael Chen',
    role: 'Full Stack Developer',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    content: 'The Python scripts are well-documented and work flawlessly. The web scraper alone has automated 90% of my data collection tasks.',
    rating: 5,
  },
  {
    id: 3,
    name: 'Emily Davis',
    role: 'Marketing Director',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
    content: 'DesignCraft has become our go-to resource for all visual content. The AI-generated images are stunning and perfectly fit our brand.',
    rating: 5,
  },
  {
    id: 4,
    name: 'James Wilson',
    role: 'Freelance Developer',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    content: 'Best investment I have made for my freelance business. The scripts are clean, efficient, and the support team is amazing.',
    rating: 5,
  },
  {
    id: 5,
    name: 'Lisa Anderson',
    role: 'Creative Director',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
    content: 'The design templates are modern, professional, and easy to customize. My clients love the results every single time.',
    rating: 5,
  },
  {
    id: 6,
    name: 'Robert Taylor',
    role: 'Startup Founder',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
    content: 'DesignCraft helped us launch our MVP in half the time. The resources are top-notch and the prices are very reasonable.',
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 bg-[#0a0b10]" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-amber-500/3 rounded-full blur-[150px]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-sm font-medium mb-4">
            <Star className="w-4 h-4" />
            Testimonials
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Loved by <span className="text-gradient">Creators</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            See what our customers have to say about their experience with DesignCraft.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="group p-6 rounded-2xl bg-[#0d0e14] border border-white/5 hover:border-white/10 transition-all duration-300"
            >
              {/* Quote Icon */}
              <Quote className="w-8 h-8 text-amber-500/20 mb-4" />

              {/* Rating */}
              <div className="flex gap-0.5 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-amber-500 fill-amber-500" />
                ))}
              </div>

              {/* Content */}
              <p className="text-gray-300 text-sm leading-relaxed mb-6">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500/20"
                />
                <div>
                  <div className="text-white font-medium text-sm">{testimonial.name}</div>
                  <div className="text-gray-500 text-xs">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
