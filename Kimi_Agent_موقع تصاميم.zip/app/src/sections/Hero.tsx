import { ArrowRight, Sparkles, Code2, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Hero() {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[#090a0f]">
        {/* Gradient Orbs */}
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-amber-500/10 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-emerald-500/8 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-500/5 rounded-full blur-[150px]" />
        {/* Grid Pattern */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 lg:py-40">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-sm font-medium mb-8">
              <Sparkles className="w-4 h-4" />
              Premium Creative Resources
            </div>

            {/* Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-[1.1] mb-6">
              Elevate Your
              <span className="block text-gradient mt-2">Creative Workflow</span>
            </h1>

            {/* Description */}
            <p className="text-lg sm:text-xl text-gray-400 max-w-xl mx-auto lg:mx-0 mb-10 leading-relaxed">
              Premium design templates, powerful Python scripts, and stunning AI-generated visuals. Everything you need to create faster.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
              <Button
                onClick={() => scrollToSection('#designs')}
                className="bg-amber-500 hover:bg-amber-400 text-black font-semibold px-8 py-6 text-lg group"
              >
                Explore Products
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                onClick={() => scrollToSection('#about')}
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 px-8 py-6 text-lg"
              >
                Learn More
              </Button>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 justify-center lg:justify-start">
              {[
                { value: '500+', label: 'Products' },
                { value: '10K+', label: 'Customers' },
                { value: '99%', label: 'Satisfaction' },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-2xl sm:text-3xl font-bold text-white">{stat.value}</div>
                  <div className="text-sm text-gray-500">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Visual */}
          <div className="hidden lg:block relative">
            <div className="relative w-full aspect-square max-w-lg mx-auto">
              {/* Main Card */}
              <div className="absolute top-0 right-0 w-72 h-80 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl border border-white/10 p-6 shadow-2xl transform rotate-6 hover:rotate-3 transition-transform duration-500">
                <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center mb-4">
                  <Palette className="w-6 h-6 text-amber-400" />
                </div>
                <div className="h-4 w-3/4 bg-white/20 rounded mb-3" />
                <div className="h-3 w-1/2 bg-white/10 rounded mb-6" />
                <div className="space-y-2">
                  <div className="h-20 bg-white/5 rounded-lg" />
                  <div className="h-20 bg-white/5 rounded-lg" />
                </div>
                <div className="absolute -bottom-3 -right-3 px-4 py-2 bg-amber-500 text-black text-sm font-bold rounded-lg">
                  $29
                </div>
              </div>

              {/* Secondary Card */}
              <div className="absolute bottom-0 left-0 w-72 h-80 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl border border-white/10 p-6 shadow-2xl transform -rotate-3 hover:-rotate-1 transition-transform duration-500">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center mb-4">
                  <Code2 className="w-6 h-6 text-emerald-400" />
                </div>
                <div className="h-4 w-3/4 bg-white/20 rounded mb-3" />
                <div className="h-3 w-1/2 bg-white/10 rounded mb-6" />
                <div className="font-mono text-xs text-emerald-400 space-y-1">
                  <div>{`def automate():`}</div>
                  <div>{`  return "success"`}</div>
                  <div>{`# Python Script`}</div>
                </div>
                <div className="absolute -bottom-3 -right-3 px-4 py-2 bg-emerald-500 text-black text-sm font-bold rounded-lg">
                  $49
                </div>
              </div>

              {/* Floating Badge */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 px-6 py-3 bg-white/10 backdrop-blur-xl rounded-full border border-white/20 text-white font-semibold shadow-xl">
                New Arrivals ✨
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="text-xs text-gray-500 uppercase tracking-widest">Scroll</span>
        <div className="w-6 h-10 rounded-full border-2 border-white/20 flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-amber-500 rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  );
}
