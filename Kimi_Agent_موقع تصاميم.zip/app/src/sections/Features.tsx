import { Zap, Shield, Clock, Headphones, Globe, Gift } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'Instant Delivery',
    description: 'Get immediate access to your purchases right after payment. No waiting required.',
    color: 'amber',
  },
  {
    icon: Shield,
    title: 'Secure Payments',
    description: 'All transactions are encrypted and processed through secure payment gateways.',
    color: 'emerald',
  },
  {
    icon: Clock,
    title: 'Lifetime Updates',
    description: 'Receive free updates for life on all purchased products and templates.',
    color: 'blue',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Our dedicated support team is available around the clock to help you.',
    color: 'purple',
  },
  {
    icon: Globe,
    title: 'Commercial License',
    description: 'All products come with a commercial license for unlimited projects.',
    color: 'rose',
  },
  {
    icon: Gift,
    title: 'Regular Freebies',
    description: 'Get access to exclusive free resources and weekly giveaways.',
    color: 'cyan',
  },
];

const colorMap: Record<string, { bg: string; text: string; border: string }> = {
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20' },
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20' },
  blue: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/20' },
  purple: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/20' },
  rose: { bg: 'bg-rose-500/10', text: 'text-rose-400', border: 'border-rose-500/20' },
  cyan: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/20' },
};

export default function Features() {
  return (
    <section className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 bg-[#0a0b10]" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/3 rounded-full blur-[150px]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Why Choose <span className="text-gradient">DesignCraft</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            We provide the best experience for creators and developers with premium quality resources.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => {
            const colors = colorMap[feature.color];
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="group p-6 rounded-2xl bg-[#0d0e14] border border-white/5 hover:border-white/10 transition-all duration-300 hover:-translate-y-1"
              >
                <div className={`w-12 h-12 rounded-xl ${colors.bg} border ${colors.border} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className={`w-6 h-6 ${colors.text}`} />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
