import { ArrowRight, Star, Download, Terminal, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';

const scripts = [
  {
    id: 1,
    title: 'Web Scraper Pro',
    description: 'Advanced web scraping tool with proxy rotation and CAPTCHA solving.',
    price: 49,
    rating: 4.9,
    sales: 876,
    tags: ['Selenium', 'BeautifulSoup', 'Requests'],
    code: `import requests
from bs4 import BeautifulSoup

def scrape_data(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    return soup.find_all('div', class_='item')`,
  },
  {
    id: 2,
    title: 'Auto Email Sender',
    description: 'Bulk email automation with templates and scheduling support.',
    price: 39,
    rating: 4.8,
    sales: 654,
    tags: ['smtplib', 'email', 'schedule'],
    code: `import smtplib
from email.mime.text import MIMEText

def send_email(to, subject, body):
    msg = MIMEText(body)
    msg['Subject'] = subject
    server = smtplib.SMTP('smtp.gmail.com')`,
  },
  {
    id: 3,
    title: 'Data Cleaner',
    description: 'Clean and transform messy datasets into structured formats.',
    price: 29,
    rating: 4.7,
    sales: 543,
    tags: ['Pandas', 'NumPy', 'Regex'],
    code: `import pandas as pd
import numpy as np

def clean_data(df):
    df = df.dropna()
    df = df.drop_duplicates()
    return df.reset_index(drop=True)`,
  },
  {
    id: 4,
    title: 'Social Media Bot',
    description: 'Automate social media posts across multiple platforms.',
    price: 59,
    rating: 4.8,
    sales: 432,
    tags: ['API', 'OAuth', 'Cron'],
    code: `import tweepy
import facebook

def post_update(text, platforms):
    for platform in platforms:
        api = get_api(platform)
        api.post(text)`,
  },
  {
    id: 5,
    title: 'PDF Generator',
    description: 'Generate professional PDFs from templates and data sources.',
    price: 34,
    rating: 4.9,
    sales: 765,
    tags: ['ReportLab', 'Jinja2', 'WeasyPrint'],
    code: `from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

def create_pdf(filename):
    c = canvas.Canvas(filename, pagesize=A4)
    c.drawString(100, 700, "Hello!")`,
  },
  {
    id: 6,
    title: 'API Builder',
    description: 'Build REST APIs quickly with authentication and documentation.',
    price: 69,
    rating: 4.9,
    sales: 389,
    tags: ['Flask', 'FastAPI', 'Swagger'],
    code: `from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

@app.get("/items/{item_id}")
async def read_item(item_id: int):`,
  },
];

export default function Scripts() {
  return (
    <section id="scripts" className="py-24 lg:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-[#0a0b10]" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-emerald-500/5 rounded-full blur-[150px]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-16">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm font-medium mb-4">
              <Terminal className="w-4 h-4" />
              Python Scripts
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Powerful <span className="text-emerald-400">Scripts</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-xl">
              Ready-to-use Python scripts to automate your workflow and boost productivity.
            </p>
          </div>
          <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 group self-start lg:self-auto">
            View All Scripts
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {scripts.map((product) => (
            <div
              key={product.id}
              className="group bg-[#0d0e14] rounded-2xl border border-white/5 overflow-hidden card-hover hover:border-emerald-500/30"
            >
              {/* Code Preview */}
              <div className="relative h-44 bg-[#0f1117] p-4 overflow-hidden">
                <div className="flex items-center gap-1.5 mb-3">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                  <div className="w-3 h-3 rounded-full bg-green-500/80" />
                  <span className="ml-2 text-xs text-gray-600 font-mono">{product.title.toLowerCase().replace(/\s/g, '_')}.py</span>
                </div>
                <pre className="text-xs text-gray-400 font-mono leading-relaxed overflow-hidden">
                  <code>{product.code}</code>
                </pre>
                <div className="absolute top-4 right-4 px-3 py-1 bg-black/60 backdrop-blur-sm rounded-full text-white font-bold text-sm">
                  ${product.price}
                </div>
                {/* Gradient Fade */}
                <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-[#0d0e14] to-transparent" />
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-emerald-400 transition-colors">
                  {product.title}
                </h3>
                <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                  {product.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {product.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 text-xs font-medium bg-white/5 text-gray-300 rounded-md border border-white/10"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <div className="flex items-center gap-3 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      {product.rating}
                    </span>
                    <span className="flex items-center gap-1">
                      <Download className="w-4 h-4" />
                      {product.sales.toLocaleString()}
                    </span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold"
                  >
                    <Copy className="w-3.5 h-3.5 mr-1" />
                    Get Script
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
