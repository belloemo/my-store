import { Image, ArrowRight, Star, Download, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';

const images = [
  {
    id: 1,
    title: 'Neon Cityscapes',
    description: 'Cyberpunk city backgrounds with neon lights and rain effects.',
    price: 15,
    rating: 4.9,
    sales: 2340,
    tags: ['4K', 'PNG', 'Background'],
    image: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=600&h=400&fit=crop',
  },
  {
    id: 2,
    title: 'Abstract Waves',
    description: 'Flowing abstract gradients perfect for modern websites.',
    price: 12,
    rating: 4.8,
    sales: 1890,
    tags: ['4K', 'JPG', 'Gradient'],
    image: 'https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=600&h=400&fit=crop',
  },
  {
    id: 3,
    title: 'Tech Patterns',
    description: 'Geometric tech patterns for branding and UI decoration.',
    price: 18,
    rating: 4.9,
    sales: 1560,
    tags: ['SVG', 'Pattern', 'Tech'],
    image: 'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=600&h=400&fit=crop',
  },
  {
    id: 4,
    title: 'Nature Collection',
    description: 'Stunning nature photography for environmental projects.',
    price: 22,
    rating: 4.7,
    sales: 980,
    tags: ['4K', 'JPG', 'Nature'],
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=400&fit=crop',
  },
  {
    id: 5,
    title: '3D Renders',
    description: 'High-quality 3D renders for product mockups.',
    price: 35,
    rating: 4.9,
    sales: 760,
    tags: ['PNG', '3D', 'Mockup'],
    image: 'https://images.unsplash.com/photo-1633218388467-539651dcf81a?w=600&h=400&fit=crop',
  },
  {
    id: 6,
    title: 'Space Universe',
    description: 'Cosmic space visuals with stars, galaxies, and nebulae.',
    price: 20,
    rating: 4.8,
    sales: 1120,
    tags: ['4K', 'JPG', 'Space'],
    image: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=600&h=400&fit=crop',
  },
];

export default function Images() {
  return (
    <section id="images" className="py-24 lg:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-[#090a0f]" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-purple-500/5 rounded-full blur-[150px]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-16">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-sm font-medium mb-4">
              <Image className="w-4 h-4" />
              AI-Generated Images
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Stunning <span className="text-purple-400">Visuals</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-xl">
              High-quality AI-generated images, backgrounds, and illustrations for any project.
            </p>
          </div>
          <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 group self-start lg:self-auto">
            View All Images
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((product) => (
            <div
              key={product.id}
              className="group bg-[#0d0e14] rounded-2xl border border-white/5 overflow-hidden card-hover hover:border-purple-500/30"
            >
              {/* Image */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0e14] via-transparent to-transparent opacity-80" />
                
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                  <button className="p-3 bg-white/10 backdrop-blur-sm rounded-full text-white hover:bg-white/20 transition-colors">
                    <Eye className="w-5 h-5" />
                  </button>
                  <button className="p-3 bg-white/10 backdrop-blur-sm rounded-full text-white hover:bg-white/20 transition-colors">
                    <Download className="w-5 h-5" />
                  </button>
                </div>

                <div className="absolute top-4 right-4 px-3 py-1 bg-black/60 backdrop-blur-sm rounded-full text-white font-bold text-sm">
                  ${product.price}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-400 transition-colors">
                  {product.title}
                </h3>
                <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                  {product.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {product.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 text-xs font-medium bg-white/5 text-gray-300 rounded-md border border-white/10"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <div className="flex items-center gap-3 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      {product.rating}
                    </span>
                    <span className="flex items-center gap-1">
                      <Download className="w-4 h-4" />
                      {product.sales.toLocaleString()}
                    </span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-purple-600 hover:bg-purple-500 text-white font-semibold"
                  >
                    Add to Cart
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
