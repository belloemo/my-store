import { Zap, Heart } from 'lucide-react';

const footerLinks = {
  Products: [
    { name: 'UI Kits', href: '#designs' },
    { name: 'Dashboards', href: '#designs' },
    { name: 'Python Scripts', href: '#scripts' },
    { name: 'AI Images', href: '#images' },
    { name: 'Icon Packs', href: '#designs' },
  ],
  Company: [
    { name: 'About Us', href: '#about' },
    { name: 'Careers', href: '#' },
    { name: 'Blog', href: '#' },
    { name: 'Press Kit', href: '#' },
  ],
  Support: [
    { name: 'Help Center', href: '#' },
    { name: 'Terms of Service', href: '#' },
    { name: 'Privacy Policy', href: '#' },
    { name: 'License Info', href: '#' },
    { name: 'Contact', href: '#contact' },
  ],
};

export default function Footer() {
  const scrollToSection = (href: string) => {
    if (href === '#') return;
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="relative bg-[#06070a] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <button
              onClick={() => scrollToSection('#home')}
              className="flex items-center gap-2 mb-4"
            >
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
                <Zap className="w-5 h-5 text-black" />
              </div>
              <span className="text-xl font-bold font-['Space_Grotesk'] text-white">
                Design<span className="text-amber-400">Craft</span>
              </span>
            </button>
            <p className="text-gray-500 text-sm leading-relaxed max-w-sm mb-6">
              Premium design resources and Python scripts for creators and developers. Build better projects faster.
            </p>
            <div className="flex gap-3">
              {['Twitter', 'GitHub', 'Dribbble'].map((social) => (
                <button
                  key={social}
                  className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-gray-500 hover:text-white hover:bg-white/10 transition-colors border border-white/5"
                >
                  {social[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="text-white font-semibold mb-4">{category}</h4>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.name}>
                    <button
                      onClick={() => scrollToSection(link.href)}
                      className="text-gray-500 hover:text-amber-400 transition-colors text-sm"
                    >
                      {link.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-600 text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-red-500 fill-red-500" /> by DesignCraft Team
          </p>
          <p className="text-gray-600 text-sm">
            &copy; {new Date().getFullYear()} DesignCraft. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
