import { Palette, ArrowRight, Star, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

const designs = [
  {
    id: 1,
    title: 'Modern UI Kit',
    description: 'Complete UI kit with 200+ components for modern web apps.',
    price: 29,
    rating: 4.9,
    sales: 2340,
    tags: ['Figma', 'React', 'Tailwind'],
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600&h=400&fit=crop',
  },
  {
    id: 2,
    title: 'Dashboard Pro',
    description: 'Admin dashboard template with dark/light mode support.',
    price: 49,
    rating: 4.8,
    sales: 1850,
    tags: ['HTML', 'CSS', 'JS'],
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop',
  },
  {
    id: 3,
    title: 'E-Commerce Pack',
    description: 'Full e-commerce design system with product pages.',
    price: 39,
    rating: 4.9,
    sales: 1520,
    tags: ['Figma', 'Sketch'],
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop',
  },
  {
    id: 4,
    title: 'Mobile App UI',
    description: 'iOS & Android app UI kit with 100+ screens.',
    price: 35,
    rating: 4.7,
    sales: 980,
    tags: ['Figma', 'Adobe XD'],
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&h=400&fit=crop',
  },
  {
    id: 5,
    title: 'Icon Library',
    description: '5000+ premium vector icons in multiple styles.',
    price: 19,
    rating: 4.9,
    sales: 3210,
    tags: ['SVG', 'PNG'],
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600&h=400&fit=crop',
  },
  {
    id: 6,
    title: 'Landing Pages',
    description: '20 high-converting landing page templates.',
    price: 45,
    rating: 4.8,
    sales: 1120,
    tags: ['HTML', 'React'],
    image: 'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=600&h=400&fit=crop',
  },
];

export default function Designs() {
  return (
    <section id="designs" className="py-24 lg:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-[#090a0f]" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-amber-500/5 rounded-full blur-[150px]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-16">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-sm font-medium mb-4">
              <Palette className="w-4 h-4" />
              Design Templates
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Premium <span className="text-gradient">Designs</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-xl">
              Professional UI kits, dashboards, and design systems crafted for modern creators.
            </p>
          </div>
          <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 group self-start lg:self-auto">
            View All Designs
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {designs.map((product) => (
            <div
              key={product.id}
              className="group bg-[#0d0e14] rounded-2xl border border-white/5 overflow-hidden card-hover hover:border-amber-500/30"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0e14] to-transparent opacity-60" />
                <div className="absolute top-4 right-4 px-3 py-1 bg-black/60 backdrop-blur-sm rounded-full text-white font-bold text-sm">
                  ${product.price}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-amber-400 transition-colors">
                  {product.title}
                </h3>
                <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                  {product.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {product.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 text-xs font-medium bg-white/5 text-gray-300 rounded-md border border-white/10"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <div className="flex items-center gap-3 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      {product.rating}
                    </span>
                    <span className="flex items-center gap-1">
                      <Download className="w-4 h-4" />
                      {product.sales.toLocaleString()}
                    </span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-amber-500 hover:bg-amber-400 text-black font-semibold"
                  >
                    Add to Cart
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
