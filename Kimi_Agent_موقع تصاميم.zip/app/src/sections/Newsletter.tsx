import { useState } from 'react';
import { Mail, ArrowRight, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setTimeout(() => {
        setIsSubscribed(false);
        setEmail('');
      }, 3000);
    }
  };

  return (
    <section className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 bg-[#0a0b10]" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-amber-500/5 rounded-full blur-[150px]" />

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center p-8 sm:p-12 rounded-3xl bg-[#0d0e14] border border-white/5">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-6">
            <Mail className="w-7 h-7 text-amber-400" />
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-4">
            Stay in the <span className="text-gradient">Loop</span>
          </h2>
          <p className="text-gray-400 max-w-lg mx-auto mb-8">
            Subscribe to our newsletter and get exclusive access to free resources, early product launches, and special discounts.
          </p>

          {isSubscribed ? (
            <div className="flex items-center justify-center gap-2 text-emerald-400">
              <CheckCircle className="w-5 h-5" />
              <span className="font-medium">Thanks for subscribing!</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="flex-1 bg-[#0a0b10] border-white/10 text-white placeholder:text-gray-600 focus:border-amber-500/50 py-6"
                required
              />
              <Button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-black font-semibold px-6 py-6 group"
              >
                Subscribe
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </form>
          )}

          <p className="text-gray-600 text-xs mt-4">
            No spam, unsubscribe at any time. Join 5,000+ subscribers.
          </p>
        </div>
      </div>
    </section>
  );
}
