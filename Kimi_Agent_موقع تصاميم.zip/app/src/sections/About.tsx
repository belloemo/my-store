import { Target, Users, TrendingUp, Award } from 'lucide-react';

const stats = [
  { icon: Users, value: '10,000+', label: 'Happy Customers', color: 'text-amber-400' },
  { icon: TrendingUp, value: '500+', label: 'Products Available', color: 'text-emerald-400' },
  { icon: Award, value: '50+', label: 'Awards Won', color: 'text-purple-400' },
  { icon: Target, value: '100%', label: 'Quality Focused', color: 'text-rose-400' },
];

export default function About() {
  return (
    <section id="about" className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 bg-[#090a0f]" />
      <div className="absolute bottom-0 left-1/4 w-[500px] h-[300px] bg-emerald-500/5 rounded-full blur-[150px]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left - Content */}
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-gray-400 text-sm font-medium mb-6">
              <Award className="w-4 h-4 text-amber-400" />
              About Us
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
              Crafting Digital
              <span className="block text-gradient">Excellence Since 2020</span>
            </h2>
            <div className="space-y-4 text-gray-400 leading-relaxed mb-8">
              <p>
                DesignCraft is a premium marketplace for designers, developers, and creators. We curate the highest quality resources to help you build amazing projects faster.
              </p>
              <p>
                Our team of expert designers and developers work tirelessly to create resources that meet the highest standards. From UI kits to Python scripts, every product is crafted with attention to detail.
              </p>
              <p>
                Join over 10,000 satisfied customers who trust DesignCraft for their creative needs. We are committed to providing exceptional value and continuous innovation.
              </p>
            </div>

            {/* Stats Row */}
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat) => {
                const Icon = stat.icon;
                return (
                  <div
                    key={stat.label}
                    className="p-4 rounded-xl bg-[#0d0e14] border border-white/5"
                  >
                    <Icon className={`w-6 h-6 ${stat.color} mb-2`} />
                    <div className="text-2xl font-bold text-white">{stat.value}</div>
                    <div className="text-sm text-gray-500">{stat.label}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right - Visual */}
          <div className="relative">
            <div className="relative w-full aspect-square max-w-md mx-auto">
              {/* Main Image */}
              <div className="absolute inset-0 rounded-3xl overflow-hidden border border-white/10">
                <img
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=800&fit=crop"
                  alt="Our Team"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#090a0f] via-transparent to-transparent opacity-60" />
              </div>

              {/* Floating Cards */}
              <div className="absolute -top-4 -right-4 px-6 py-4 bg-[#0d0e14] border border-white/10 rounded-2xl shadow-xl">
                <div className="text-3xl font-bold text-amber-400">4.9</div>
                <div className="text-sm text-gray-400">Average Rating</div>
                <div className="flex gap-0.5 mt-1">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-4 h-4 text-amber-500 fill-amber-500" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>

              <div className="absolute -bottom-4 -left-4 px-6 py-4 bg-[#0d0e14] border border-white/10 rounded-2xl shadow-xl">
                <div className="text-3xl font-bold text-emerald-400">24/7</div>
                <div className="text-sm text-gray-400">Customer Support</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
