import Navbar from './sections/Navbar';
import Hero from './sections/Hero';
import Designs from './sections/Designs';
import Scripts from './sections/Scripts';
import Images from './sections/Images';
import Features from './sections/Features';
import About from './sections/About';
import Testimonials from './sections/Testimonials';
import Newsletter from './sections/Newsletter';
import Contact from './sections/Contact';
import Footer from './sections/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#090a0f] text-white overflow-x-hidden">
      <Navbar />
      <Hero />
      <Designs />
      <Scripts />
      <Images />
      <Features />
      <About />
      <Testimonials />
      <Newsletter />
      <Contact />
      <Footer />
    </div>
  );
}
